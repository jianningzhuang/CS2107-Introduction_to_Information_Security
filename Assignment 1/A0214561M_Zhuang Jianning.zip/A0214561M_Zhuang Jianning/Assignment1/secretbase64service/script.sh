#!/bin/bash

nc cs2107-ctfd-i.comp.nus.edu.sg 4002

echo 2
