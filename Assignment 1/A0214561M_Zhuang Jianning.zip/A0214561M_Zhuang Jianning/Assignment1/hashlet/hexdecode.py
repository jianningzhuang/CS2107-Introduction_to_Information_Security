print(bytes.fromhex('e236a845daaf9791e159f5b302d42b46').decode())
