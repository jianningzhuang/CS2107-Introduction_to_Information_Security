# pwntools is a very powerful library for doing exploitation
from pwn import *

# TODO: Update with actual values
HOST = ""
PORT = 31337
BINARY = "./bof"

p = process(BINARY)   # use process instead of remote to execute the local version of the program
#p = remote(HOST, PORT)  # to open a connection to the remote service, aka the challenge

# TODO: Fill in your payload
PADDING = b""
RETURN_ADDRESS = 0x0
PAYLOAD = PADDING + p64(RETURN_ADDRESS)    # p64 converts an integer to 8-byte little endian bytestring format
p.sendline(PAYLOAD)

# earlier, the script helps us send/receive data to/from the service
# with interactive, we can directly interact with the service
p.interactive()
